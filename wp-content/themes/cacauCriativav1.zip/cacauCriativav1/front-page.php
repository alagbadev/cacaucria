<?php get_header(); ?>
<main>
<section id="banner">
    <div class="container">
        <div class="banner-content">
            <div class="content-left"> <!-- Nova div para alinhar o conteúdo -->
                <h1>Cacau Criativa <span id="dynamicText"></span></h1>
                <p> Impulsionamos seu impacto social com soluções digitais inovadoras e personalizadas.</p>
                <a href="#servicos"><button type="button" class="btn-topo">Saiba mais</button></a>
            </div>
        </div>
    </div>
</section>

<div class="painel-de-servicos">
    <div id="servicos">
       <font color="#fff"> <h2>Descubra como podemos ajudar.</font></h2>
        <p id="paragrafo">Conheça nossos serviços digitais para negócios sociais:</p>
            <div class="cards">
                <div class="card">
                <i class="fa-brands fa-react"></i>
                <div class="conteudo">
                    <h3>De sites à sistemas complexos.</h3>
                    <p>Seja para garantir a presença digital do seu negócio social ou gerenciar seus projetos e equipe 
                        em um painel integrado ao seu portal, a Cacau Criativa tem a solução.</p>
                       <!-- <button type="button" class="btn-topo" >Saiba mais</button> -->
                </div>
            </div>

            <div class="card">
                <i class="fa-regular fa-gem"></i>
                <div class="conteudo">
                    <h3>Plataformas educativas para seu projeto de impacto.</h3>
                    <p>Na Cacau Criativa criamos plataformas tecnológicas
                        personalizadas com a cara do seu negócio social. Aqui, digitalizamos seu modelo de negócios educativo.</p>
                        <!-- <button type="button" class="btn-topo" >Saiba mais</button> -->
                </div>
            </div>

            <div class="card">
                <i class="fa-solid fa-rocket"></i>
                <div class="conteudo">
                    <h3>Cursos e formações para capacitação do seu time.</h3>
                    <p>Precisa atualizar o seu time sobre novas perspecitvas digitais para 
                        seu negócio social ou incluir formação digital no seu projeto? Conheça nossos cursos e formações.</p>
                         <!-- <button type="button" class="btn-topo">Saiba mais</button> -->
                </div>
            </div>
            </div>


    </div>
</div>
<div id="sobre">
<div id="sessao">
<div class="sessao-sobre">
    <div class="sobre-container">
        <h1>Sobre nós</h1>
        <p class="sessao-text">Na Cacau Criativa, nossa missão é impulsionar mudanças positivas no mundo por meio da tecnologia. <br>
            Desde 2021, temos sido parceiros de confiança para negócios sociais, empreendedores, ativistas e instituições com propósito, oferecendo soluções digitais inovadoras que fortalecem sua presença online e facilitam suas operações. <br>
            Nossa abordagem personalizada e focada na colaboração nos permite criar sistemas e plataformas adaptadas às necessidades específicas de cada cliente. <br> Acreditamos que, ao apoiar projetos e iniciativas que impactam a vida das pessoas, estamos contribuindo para um futuro melhor. <br>
            <b>A Cacau Criativa não é apenas sobre tecnologia, mas sobre construir pontes que possibilitem o crescimento sustentável e a transformação social.</b></p>
        <div class="habilidades">
            <span>Design Estratégico</span>
            <span>Soluções Automatizadas</span>
            <span>Desenvolvimento Ágil</span>
        </div>
    </div>
</div>
</div>
</div>
<section id="blog">
    <div class="blog-heading">
        <span>Últimos artigos</span>
        <h3>Blog da Cacau Criativa</h3>
    </div>

    <div class="blog-container">
        <?php
        // Obtém as últimas 3 publicações do WordPress
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => 3,
            'order' => 'DESC',
            'orderby' => 'date',
        );

        $query = new WP_Query($args);

        // Loop pelas postagens
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
        ?>
                <div class="blog-box">
                    <!-- Imagem em destaque -->
                    <div class="blog-img">
                        <?php
                        if (has_post_thumbnail()) {
                            the_post_thumbnail();
                        } else {
                            echo '<img src="' . esc_url(get_template_directory_uri() . '/placeholder.jpg') . '" alt="Imagem do blog">';
                        }
                        ?>
                    </div>

                    <!-- Conteúdo da postagem -->
                    <div class="blog-text">
                        <span><?php echo get_the_date('F Y'); ?></span>
                        <a href="<?php the_permalink(); ?>" class="blog-title"><?php the_title(); ?></a>
                        <p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                        <a href="<?php the_permalink(); ?>">Saber Mais</a>
                    </div>
                </div>
        <?php
            endwhile;
            wp_reset_postdata(); // Restaura os dados originais da consulta
        endif;
        ?>
    </div>
</section>

    <div id="contato">
    <section id="form">
        <div class="contact-container">
            <form action="https://api.web3forms.com/submit" method="POST" class="contact-left">
                <div class="contact-left-title">
                        <h2>Envie um email</h2>
                    <hr>
                </div>
                <input type="hidden" name="access_key" value="dd4ad790-5a02-49bb-9d17-1fad65647bed">
                    <input type="text" name="nome" placeholder="Seu Nome" class="contact-inputs" required>
                    <input type="email" name="email" placeholder="Seu Email" class="contact-inputs" required>
                    <textarea name="mensagem" placeholder="Sua Mensagem" class="contact-inputs" required></textarea>
                    <button type="submit" class="custom-button">Enviar<i class="fa-regular fa-paper-plane" alt="Envir email"></i></button>
            </form>
            <div class="contact-right">
                <div class="container-right-title"><h2>ou agende uma reunião.</h2> </div>
                   <a href="https://calendly.com/cacau-helder/reuniao-com-a-cacau-criativa" alt="Agendar reunião"><button class="custom-button">Agendar<i class="fa-regular fa-calendar-days"></i></button></a></div>
                <hr>
            </div>
        </div>

    </section>
</div>    
    
</main>
<?php get_footer(); ?>
