<?php get_header(); ?>
<main>
  <!-- Seu conteúdo HTML aqui -->
</main>
<?php get_footer(); ?>
