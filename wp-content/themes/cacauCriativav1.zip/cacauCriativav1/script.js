document.addEventListener('DOMContentLoaded', function() {
    // Código para animação de texto dinâmico
    var dynamicText = document.getElementById('dynamicText');
    var words = ["Inovação.", "Sustentabilidade.", "impacto."];
    var currentIndex = 0;
    var currentWord = '';
    var index = 0;
    var typingSpeed = 100; // Velocidade de digitação em milissegundos

    function changeWord() {
        if (index < words[currentIndex].length) {
            currentWord += words[currentIndex].charAt(index);
            dynamicText.textContent = currentWord;
            index++;
            setTimeout(changeWord, typingSpeed);
        } else {
            setTimeout(eraseWord, 1000); // Aguarda 1 segundo antes de apagar a palavra
        }
    }

    function eraseWord() {
        if (currentWord.length > 0) {
            currentWord = currentWord.slice(0, -1);
            dynamicText.textContent = currentWord;
            setTimeout(eraseWord, typingSpeed / 2); // Velocidade para apagar é metade da velocidade para escrever
        } else {
            currentIndex = (currentIndex + 1) % words.length;
            index = 0;
            setTimeout(changeWord, 500); // Aguarda 0.5 segundo antes de começar a próxima palavra
        }
    }

    setTimeout(changeWord, 1000); // Aguarda 1 segundo antes de começar a primeira palavra

    // Classe MobileNavbar para gerenciar o menu móvel
    class MobileNavbar {
        constructor(mobileMenu, navList, navLinks) {
            this.mobileMenu = document.querySelector(mobileMenu);
            this.navList = document.querySelector(navList);
            this.navLinks = document.querySelectorAll(navLinks);
            this.activeClass = "active";

            this.handleClick = this.handleClick.bind(this);
        }

        animateLinks() {
            this.navLinks.forEach((link, index) => {
                link.style.animation = link.style.animation
                    ? ""
                    : `navLinkFade 0.5s ease forwards ${index / 7 + 0.3}s`;
            });
        }

        handleClick() {
            this.navList.classList.toggle(this.activeClass);
            this.mobileMenu.classList.toggle(this.activeClass);
            this.animateLinks();
        }

        addClickEvent() {
            this.mobileMenu.addEventListener("click", this.handleClick);
        }

        init() {
            if (this.mobileMenu) {
                this.addClickEvent();
            }
            return this;
        }
    }

    const mobileNavbar = new MobileNavbar(
        ".mobile-menu",
        ".nav-list",
        ".nav-list li"
    );

    mobileNavbar.init();
});
