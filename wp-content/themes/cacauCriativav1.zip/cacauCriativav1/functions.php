<?php

function cacaucriativa_enqueue_scripts() {
  // Enqueue your stylesheet
  wp_enqueue_style('style', get_stylesheet_uri());

  // Enqueue your JavaScript file
  wp_enqueue_script('custom-script', get_template_directory_uri() . '/script.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'cacaucriativa_enqueue_scripts');

