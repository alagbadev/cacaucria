<footer>
    <div id="footer-content">
        <div id="footer-contacts">
            <h1><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon amarelo.png" alt="logo da Cacau Criativa"> Cacau Criativa </h1>
            <div id="footer-social-media">
                <a href="#" class="footer-link" id="instagram">
                    <i class=" fa-brands fa-instagram"></i>
                </a>
                <a href="#" class="footer-link" id="facebook">
                    <i class=" fa-brands fa-facebook-f"></i>
                </a>
                <a href="#" class="footer-link" id="linkedin">
                    <i class=" fa-brands fa-linkedin"></i>
                </a>
            </div>
        </div>
        <ul class="footer-list">

        </ul>
        <ul class="footer-list">
            <li>
                <h3>Blog</h3>
            </li>
            <li>
                <a href="" class="footer-link">tecnologia</a>
            </li>
            <li>
                <a href="" class="footer-link">atualizações</a>
            </li>
            <li>
                <a href="" class="footer-link">negócios sociais</a>
            </li>
            <li>
                <a href="" class="footer-link">design</a>
            </li>
        </ul>
        <ul class="footer-list">
            <li>
                <h3>Links</h3>
            </li>
            <li>
                <a href="" class="footer-link">Prazos da Cacau Criativa</a>
            </li>
            <li>
                <a href="" class="footer-link">Termos e condições</a>
            </li>
            <li>
                <a href="" class="footer-link">Privacidade</a>
            </li>
            <li>
                <a href="" class="footer-link">login</a>
            </li>
        </ul>
        <div id="footer-subscribe">
            <h3>Assine</h3>
            <p> Adicione seu email e fique por dentro 
                das últimas novidades.</p>
                <div id="input-group">
                    <input type="email" id="email">
                    <button>
                        <i class="fa-regular fa-envelope"></i>
                    </button>
                </div>
        </div>
        
       </div>
       <div id="footer-copyriting">
        &#169
        <?php echo date("Y"); ?> - Cacau Criativa - Todos os direitos reservados.
       </div>
    </footer>
</body>
</html>
